from nltk.corpus import stopwords
stop_words = stopwords.words('english')
print(stop_words)